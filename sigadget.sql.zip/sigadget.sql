-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2021 at 08:32 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sigadget`
--

-- --------------------------------------------------------

--
-- Table structure for table `kurir`
--

CREATE TABLE `kurir` (
  `ID_Kurir` int(10) UNSIGNED NOT NULL,
  `Nama_Kurir` varchar(60) NOT NULL,
  `Jenis_Kurir` varchar(60) NOT NULL,
  `Harga_Kurir` int(11) NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kurir`
--

INSERT INTO `kurir` (`ID_Kurir`, `Nama_Kurir`, `Jenis_Kurir`, `Harga_Kurir`, `Created_at`) VALUES
(1, 'JNE', 'YES', 18000, '2021-03-31 02:14:10'),
(2, 'A', 'A', 0, '2021-03-31 02:13:48'),
(3, 'JNI', 'NO', 20000, '2021-03-31 02:20:23'),
(4, 'SiLambat', 'YES', 50000, '2021-03-31 07:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `ID_Pembayaran` int(10) UNSIGNED NOT NULL,
  `Nama_Pembayaran` varchar(60) NOT NULL,
  `Jenis_Pembayaran` varchar(60) NOT NULL,
  `ID_Card` varchar(16) NOT NULL,
  `Nominal_Pembayaran` varchar(16) NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`ID_Pembayaran`, `Nama_Pembayaran`, `Jenis_Pembayaran`, `ID_Card`, `Nominal_Pembayaran`, `Created_at`) VALUES
(1, 'Mandiri Visa', 'Kartu Kredit', '1000200030004000', '54000000', '2021-03-30 15:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `ID_Penjualan` int(10) UNSIGNED NOT NULL,
  `ID_Transaksi` int(11) NOT NULL,
  `ID_Produk` int(11) NOT NULL,
  `Jumlah_Terjual` int(11) NOT NULL,
  `Total_Pendapatan` int(11) NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`ID_Penjualan`, `ID_Transaksi`, `ID_Produk`, `Jumlah_Terjual`, `Total_Pendapatan`, `Created_at`) VALUES
(1, 1, 1, 3, 54000000, '2021-03-30 14:30:00'),
(2, 1, 1, 10, 3000000, '2021-03-31 07:54:50');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `ID_Produk` int(10) UNSIGNED NOT NULL,
  `Nama_Produk` varchar(60) NOT NULL,
  `Jenis_Produk` varchar(60) NOT NULL,
  `Harga_Produk` varchar(15) NOT NULL,
  `Stok_Produk` int(10) UNSIGNED NOT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Brand` varchar(60) NOT NULL,
  `Warna` varchar(60) NOT NULL,
  `Jaringan` varchar(60) NOT NULL,
  `OS` varchar(60) NOT NULL,
  `Chipset` varchar(60) NOT NULL,
  `RAM` varchar(60) NOT NULL,
  `Storage` varchar(60) NOT NULL,
  `Layar` varchar(60) NOT NULL,
  `Kamera_Depan` varchar(60) NOT NULL,
  `Kamera_Belakang` varchar(60) NOT NULL,
  `Baterai` varchar(60) NOT NULL,
  `Tipe_Headphone` varchar(60) NOT NULL,
  `Konektivitas_Headphone` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`ID_Produk`, `Nama_Produk`, `Jenis_Produk`, `Harga_Produk`, `Stok_Produk`, `Created_at`, `Brand`, `Warna`, `Jaringan`, `OS`, `Chipset`, `RAM`, `Storage`, `Layar`, `Kamera_Depan`, `Kamera_Belakang`, `Baterai`, `Tipe_Headphone`, `Konektivitas_Headphone`) VALUES
(1, 'iPhone 12 Pro', 'Smartphone', '18000000', 30, '2021-03-29 15:54:34', '', '', '', '', '', '', '', '', '', '', '', '0', '0'),
(2, 'iPhone 12 Pro Max', 'Smartphone', '20000000', 0, '2021-03-30 18:19:12', '', '', '', '', '', '', '', '', '', '', '', '0', '0'),
(3, 'JBL 100', 'Accessories', '300000', 10, '2021-03-30 18:20:53', '', '', '', '', '', '', '', '', '', '', '', '0', '0'),
(4, 'JBL 300', 'Accessories', '350000', 20, '2021-03-31 02:11:00', '', '', '', '', '', '', '', '', '', '', '', '0', '0'),
(5, 'iPhone 8', 'Smartphone', '10000000', 5, '2021-03-31 07:59:01', '', '', '', '', '', '', '', '', '', '', '', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `ID_Transaksi` int(10) UNSIGNED NOT NULL,
  `ID_User` int(11) NOT NULL,
  `ID_Produk` int(11) NOT NULL,
  `Jumlah_Beli` int(10) UNSIGNED NOT NULL,
  `ID_Pembayaran` int(11) NOT NULL,
  `ID_Kurir` int(11) NOT NULL,
  `Waktu_Pembelian` datetime DEFAULT NULL,
  `Status_Transaksi` enum('Diproses','Dikirim','Diterima','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`ID_Transaksi`, `ID_User`, `ID_Produk`, `Jumlah_Beli`, `ID_Pembayaran`, `ID_Kurir`, `Waktu_Pembelian`, `Status_Transaksi`) VALUES
(1, 1, 1, 3, 1, 1, '2021-03-30 14:30:00', 'Diproses'),
(3, 4, 5, 10, 3, 2, '2021-03-29 21:54:03', 'Dikirim'),
(4, 4, 5, 10, 3, 2, '2021-03-30 21:54:03', 'Diterima');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID_User` int(10) UNSIGNED NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `userlevel` enum('admin','member') DEFAULT NULL,
  `Nama_Lengkap` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `No_Telepon` varchar(15) NOT NULL,
  `Alamat` varchar(60) NOT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID_User`, `username`, `password`, `userlevel`, `Nama_Lengkap`, `email`, `No_Telepon`, `Alamat`, `Created_at`, `Updated_at`) VALUES
(1, 'david', '$2y$10$vREuVSFFXrODmh8FldO6Q.3y4ZYjC5eOAUxeIfUTkskUl8.y9CchK', 'member', 'David', 'david@gmail.com', '081234567890', 'Bogor', '2021-03-15 14:14:58', '2021-03-15 14:14:58'),
(2, 'sanctus', '$2y$10$1ytH4m1s1kdQJEuNwBHJl.vSeuJsYzhKo4MEkkUKzRmW/HvQQRmJu', 'member', 'sanctus', 'sanctus@gmail.com', '081234567890', 'Jakarta', '2021-03-31 00:38:08', '2021-03-31 00:38:08'),
(3, 'migel', '$2y$10$KpzFo.BaggRfutCY1nQt3ezOSOAltSmxvzbTOSKUWttImoy2G4K3u', 'member', 'migel', 'migel@gmail.com', '081234567890', 'Tangerang', '2021-03-31 00:41:45', '2021-03-31 00:41:45'),
(4, 'tius', '$2y$10$PN7vxvN1t/TnmQK1F8Oht.J86uLXRgQJL6A9KENglzRl9nXYXj0oy', 'admin', 'tius', 'tius@gmail.com', '081234567890', 'Bogor', '2021-03-31 00:44:04', '2021-03-31 00:44:04'),
(5, 'ernest', '$2y$10$jOoivEMzzm3S8SoKEq.OXet2vpCGSDEC2LnnfXaYt2m0oNT4VlaTO', 'member', 'ernest', 'ernest@gmail.com', '081234567890', 'Surabaya', '2021-03-31 01:40:22', '2021-03-31 01:40:22'),
(6, 'jason', '$2y$10$qrb5exHer8cySnggeI3nSeiAEAsavloXPMSzCO/h1camNLJHy8U8.', 'member', 'jason', 'jason@gmail.com', '081234567890', 'Tangerang', '2021-03-31 07:50:16', '2021-03-31 07:50:16'),
(7, 'yofan', '$2y$10$tQusZvhVc6hRn4jytzNHB.uNaYtcRL79HX.MEqZl6gWOgVxGF8MYa', 'admin', 'yofan', 'yofan@gmail.com', '081234567890', 'Lampung', '2021-03-31 08:00:13', '2021-03-31 08:00:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kurir`
--
ALTER TABLE `kurir`
  ADD PRIMARY KEY (`ID_Kurir`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`ID_Pembayaran`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`ID_Penjualan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`ID_Produk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`ID_Transaksi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_User`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kurir`
--
ALTER TABLE `kurir`
  MODIFY `ID_Kurir` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `ID_Pembayaran` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `ID_Penjualan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `ID_Produk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `ID_Transaksi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID_User` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
