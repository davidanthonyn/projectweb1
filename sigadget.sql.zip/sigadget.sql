-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2021 at 02:01 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sigadget`
--

-- --------------------------------------------------------

--
-- Table structure for table `kurir`
--

CREATE TABLE `kurir` (
  `ID_Kurir` int(10) UNSIGNED NOT NULL,
  `Nama_Kurir` varchar(60) NOT NULL,
  `Produk_Kurir` varchar(60) NOT NULL,
  `Harga_Kurir` int(10) UNSIGNED NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kurir`
--

INSERT INTO `kurir` (`ID_Kurir`, `Nama_Kurir`, `Produk_Kurir`, `Harga_Kurir`, `Created_at`) VALUES
(1, 'JNE', 'YES', 18000, '2021-03-31 02:14:10'),
(2, 'A', 'A', 0, '2021-03-31 02:13:48'),
(3, 'JNI', 'NO', 20000, '2021-03-31 02:20:23'),
(4, 'SiLambat', 'YES', 50000, '2021-03-31 07:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `Kode_Pembayaran` int(10) UNSIGNED NOT NULL,
  `Nama_Pembayaran` varchar(60) NOT NULL,
  `Jenis_Pembayaran` enum('Kartu_Kredit','Kartu_Debit','E_Wallet','Cash_On_Delivery') NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`Kode_Pembayaran`, `Nama_Pembayaran`, `Jenis_Pembayaran`, `Created_at`) VALUES
(1, 'Mandiri Visa', 'Kartu_Debit', '2021-03-30 15:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `ID_Penjualan` int(10) UNSIGNED NOT NULL,
  `ID_Produk` int(10) UNSIGNED NOT NULL,
  `Jumlah_Terjual` int(10) NOT NULL,
  `Harga_Produk` int(10) NOT NULL,
  `Total_Harga` int(10) NOT NULL,
  `Created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`ID_Penjualan`, `ID_Produk`, `Jumlah_Terjual`, `Harga_Produk`, `Total_Harga`, `Created_at`) VALUES
(1, 1, 1, 3, 54000000, '2021-03-30 14:30:00'),
(2, 1, 1, 10, 3000000, '2021-03-31 07:54:50'),
(3, 1, 1, 10, 3000000, '2021-03-31 07:54:50');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `ID_Produk` int(10) UNSIGNED NOT NULL,
  `Nama_Produk` varchar(60) NOT NULL,
  `Jenis_Produk` varchar(60) NOT NULL,
  `Harga_Produk` varchar(15) NOT NULL,
  `Stok_Produk` int(10) UNSIGNED NOT NULL,
  `Status_Produk` enum('Pending','Published','Non-Activate') NOT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  `Brand` varchar(60) NOT NULL,
  `Warna` varchar(60) NOT NULL,
  `Jaringan` varchar(60) NOT NULL,
  `OS` varchar(60) NOT NULL,
  `Chipset` varchar(60) NOT NULL,
  `RAM` varchar(60) NOT NULL,
  `Storage` varchar(60) NOT NULL,
  `Layar` varchar(60) NOT NULL,
  `Kamera_Depan` varchar(60) NOT NULL,
  `Kamera_Belakang` varchar(60) NOT NULL,
  `Baterai` varchar(60) NOT NULL,
  `Tipe_Headphone` varchar(60) NOT NULL,
  `Konektivitas_Headphone` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`ID_Produk`, `Nama_Produk`, `Jenis_Produk`, `Harga_Produk`, `Stok_Produk`, `Status_Produk`, `Created_at`, `Updated_at`, `image`, `Brand`, `Warna`, `Jaringan`, `OS`, `Chipset`, `RAM`, `Storage`, `Layar`, `Kamera_Depan`, `Kamera_Belakang`, `Baterai`, `Tipe_Headphone`, `Konektivitas_Headphone`) VALUES
(1, 'iPhone', 'Smartphone', '30000000', 2, '', '2021-04-09 13:28:43', '2021-04-09 13:28:43', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, 'iPhone 12 Pro Max', 'Smartphone', '20000000', 0, 'Pending', '2021-03-30 18:19:12', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'JBL 100', 'Accessories', '300000', 10, 'Pending', '2021-03-30 18:20:53', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 'JBL 300', 'Accessories', '350000', 20, 'Pending', '2021-03-31 02:11:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, 'iPhone 8', 'Smartphone', '10000000', 5, 'Pending', '2021-03-31 07:59:01', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, 'iPhone SE 3', 'Smartphone', '7499000', 30, 'Published', '2021-04-06 23:28:36', '2021-04-08 22:48:05', '20200510192805_1.jpg', 'Apple', 'Hitam', '4G', 'iOS 13', 'A13 Bionic', '3 GB', '64 GB', '4.7 inch IPS LCD', '7 MP', '12 MP', '1821 mAh', '-', '-'),
(7, 'a', 'a', '300000', 3, 'Pending', '2021-04-07 01:55:01', '2021-04-07 01:55:01', 'iPhoneSEDisplayRED.png', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'aa', 'a'),
(8, 'b', 'b', 'b', 2, 'Pending', '2021-04-07 01:56:20', '2021-04-07 01:56:20', 'Product_iPhone_SE.png', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b'),
(9, 'b', 'b', 'b', 3, 'Pending', '2021-04-07 02:10:47', '2021-04-07 02:10:47', 'Anggota_Lain.png', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b'),
(11, 'iPhone 12 mini', 'Smartphone', '13.999.000', 300, 'Pending', '2021-04-08 22:50:02', '2021-04-08 22:50:02', '20200510192725_1.jpg', 'Apple', 'Hitam', '5G', 'iOS 14 ', 'A14 Bionic', '4 GB', '64 GB', '5.4 inch OLED', '12 MP', '12 MP', '2227 mAh', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `ID_Transaksi` int(10) UNSIGNED NOT NULL,
  `ID_User` int(10) UNSIGNED NOT NULL,
  `ID_Pembayaran` int(10) UNSIGNED NOT NULL,
  `ID_Pengiriman` int(10) UNSIGNED NOT NULL,
  `ID_Penjualan` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`ID_Transaksi`, `ID_User`, `ID_Pembayaran`, `ID_Pengiriman`, `ID_Penjualan`) VALUES
(1, 1, 1, 1, 1),
(3, 4, 3, 2, 2),
(4, 4, 3, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID_User` int(10) UNSIGNED NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `userlevel` enum('admin','member') DEFAULT NULL,
  `userstatus` enum('Activate','Disabled') NOT NULL,
  `Nama_Lengkap` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `No_Telepon` varchar(15) NOT NULL,
  `Alamat` varchar(60) NOT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID_User`, `username`, `password`, `userlevel`, `userstatus`, `Nama_Lengkap`, `email`, `No_Telepon`, `Alamat`, `Created_at`, `Updated_at`) VALUES
(1, 'david', '$2y$10$vREuVSFFXrODmh8FldO6Q.3y4ZYjC5eOAUxeIfUTkskUl8.y9CchK', 'member', 'Disabled', 'David', 'david@gmail.com', '081234567890', 'Bogor', '2021-03-15 14:14:58', '2021-03-15 14:14:58'),
(2, 'sanctus', '$2y$10$1ytH4m1s1kdQJEuNwBHJl.vSeuJsYzhKo4MEkkUKzRmW/HvQQRmJu', 'member', 'Activate', 'sanctus', 'sanctus@gmail.com', '081234567890', 'Jakarta', '2021-03-31 00:38:08', '2021-03-31 00:38:08'),
(3, 'migel', '$2y$10$KpzFo.BaggRfutCY1nQt3ezOSOAltSmxvzbTOSKUWttImoy2G4K3u', 'member', 'Activate', 'migel', 'migel@gmail.com', '081234567890', 'Tangerang', '2021-03-31 00:41:45', '2021-03-31 00:41:45'),
(4, 'tius', '$2y$10$PN7vxvN1t/TnmQK1F8Oht.J86uLXRgQJL6A9KENglzRl9nXYXj0oy', 'admin', 'Activate', 'tius', 'tius@gmail.com', '081234567890', 'Bogor', '2021-03-31 00:44:04', '2021-03-31 00:44:04'),
(5, 'ernest', '$2y$10$jOoivEMzzm3S8SoKEq.OXet2vpCGSDEC2LnnfXaYt2m0oNT4VlaTO', 'member', 'Activate', 'ernest', 'ernest@gmail.com', '081234567890', 'Surabaya', '2021-03-31 01:40:22', '2021-03-31 01:40:22'),
(6, 'jason', '$2y$10$qrb5exHer8cySnggeI3nSeiAEAsavloXPMSzCO/h1camNLJHy8U8.', 'member', 'Activate', 'jason', 'jason@gmail.com', '081234567890', 'Tangerang', '2021-03-31 07:50:16', '2021-03-31 07:50:16'),
(7, 'yofan', '$2y$10$tQusZvhVc6hRn4jytzNHB.uNaYtcRL79HX.MEqZl6gWOgVxGF8MYa', 'admin', 'Activate', 'yofan', 'yofan@gmail.com', '081234567890', 'Lampung', '2021-03-31 08:00:13', '2021-03-31 08:00:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kurir`
--
ALTER TABLE `kurir`
  ADD PRIMARY KEY (`ID_Kurir`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`Kode_Pembayaran`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`ID_Penjualan`),
  ADD KEY `ID_Produk` (`ID_Produk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`ID_Produk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`ID_Transaksi`),
  ADD KEY `ID_User` (`ID_User`),
  ADD KEY `ID_Pembayaran` (`ID_Pembayaran`),
  ADD KEY `ID_Pengiriman` (`ID_Pengiriman`),
  ADD KEY `ID_Penjualan` (`ID_Penjualan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_User`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kurir`
--
ALTER TABLE `kurir`
  MODIFY `ID_Kurir` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `Kode_Pembayaran` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `ID_Penjualan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `ID_Produk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `ID_Transaksi` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID_User` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`ID_Produk`) REFERENCES `produk` (`ID_Produk`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`ID_Penjualan`) REFERENCES `penjualan` (`ID_Penjualan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_3` FOREIGN KEY (`ID_Pembayaran`) REFERENCES `pembayaranuser` (`ID_Pembayaran`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
