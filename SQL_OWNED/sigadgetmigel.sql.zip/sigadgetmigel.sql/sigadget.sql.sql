-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Apr 2021 pada 06.39
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sigadget`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `ID_Produk` int(10) UNSIGNED NOT NULL,
  `Nama_Produk` varchar(60) NOT NULL,
  `Jenis_Produk` varchar(60) NOT NULL,
  `Harga_Produk` varchar(15) NOT NULL,
  `Stok_Produk` int(10) UNSIGNED NOT NULL,
  `Status_Produk` enum('Pending','Published','Non-Activate') NOT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  `Brand` varchar(60) NOT NULL,
  `Warna` varchar(60) NOT NULL,
  `Jaringan` varchar(60) NOT NULL,
  `OS` varchar(60) NOT NULL,
  `Chipset` varchar(60) NOT NULL,
  `RAM` varchar(60) NOT NULL,
  `Storage` varchar(60) NOT NULL,
  `Layar` varchar(60) NOT NULL,
  `Kamera_Depan` varchar(60) NOT NULL,
  `Kamera_Belakang` varchar(60) NOT NULL,
  `Baterai` varchar(60) NOT NULL,
  `Tipe_Headphone` varchar(60) NOT NULL,
  `Konektivitas_Headphone` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`ID_Produk`, `Nama_Produk`, `Jenis_Produk`, `Harga_Produk`, `Stok_Produk`, `Status_Produk`, `Created_at`, `Updated_at`, `image`, `Brand`, `Warna`, `Jaringan`, `OS`, `Chipset`, `RAM`, `Storage`, `Layar`, `Kamera_Depan`, `Kamera_Belakang`, `Baterai`, `Tipe_Headphone`, `Konektivitas_Headphone`) VALUES
(1, 'iPhone', 'Smartphone', '30000000', 2, '', '2021-04-09 13:28:43', '2021-04-09 13:28:43', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'JBL 100', 'Accessories', '300000', 10, 'Published', '2021-03-30 18:20:53', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, 'JBL 300', 'Accessories', '350000', 20, 'Published', '2021-03-31 02:11:00', '0000-00-00 00:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, 'iPhone 8', 'Smartphone', '10000000', 5, 'Published', '2021-03-31 07:59:01', '0000-00-00 00:00:00', '', 'Apple', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, 'iPhone 12 mini', 'Smartphone', '13999000', 300, 'Published', '2021-04-08 22:50:02', '2021-04-13 01:23:56', '20200510192725_1.jpg', 'Apple', 'Hitam', '5G', 'iOS 14 ', 'A14 Bionic', '4 GB', '64 GB', '5.4 inch OLED', '12 MP', '12 MP', '2227 mAh', '-', '-'),
(12, 'iPhone 12 Pro Max', 'Smartphone', '26999000', 100, 'Published', '2021-04-13 18:15:56', '2021-04-13 18:15:56', 'photo_2021-04-13_18-14-18.jpg', 'Apple', 'Pacific Blue', '5G', 'iOS 14', 'A14 Bionic', '6 GB', '512 GB', '6.7 inch OLED', '12 MP', '12 MP', '3687 mAh', '-', '-'),
(13, 'iPhone 12 Pro Max', 'Smartphone', '22999000', 100, 'Published', '2021-04-13 18:15:56', '2021-04-13 18:15:56', 'photo_2021-04-13_18-14-18.jpg', 'Apple', 'Pacific Blue', '5G', 'iOS 14', 'A14 Bionic', '6 GB', '256 GB', '6.7 inch OLED', '12 MP', '12 MP', '3687 mAh', '-', '-'),
(14, 'iPhone 12 Pro Max', 'Smartphone', '20499000', 100, 'Published', '2021-04-13 18:15:56', '2021-04-13 18:15:56', 'photo_2021-04-13_18-14-18.jpg', 'Apple', 'Pacific Blue', '5G', 'iOS 14', 'A14 Bionic', '6 GB', '128 GB', '6.7 inch OLED', '12 MP', '12 MP', '3687 mAh', '-', '-'),
(17, 'Samsung Galaxy S20 Ultra', 'Smartphone', '12900000', 100, 'Published', '2021-04-26 10:59:31', '2021-04-26 10:59:31', 's20 ultra cosmic grey.jpg', 'Samsung', 'Cosmic Grey', '4G', 'Android', 'Exynos 990', '8 GB', '128 GB', '6.2 inch ', '10 MP', '64 MP', '4000mAh', '-', '-'),
(18, 'Samsung Galaxy M51', 'Smartphone', '5499000', 100, 'Published', '2021-04-26 11:04:27', '2021-04-26 11:04:27', 'm51.jpg', 'Samsung', 'Black', '4G', 'Android', 'Snapdragon 730G', '8 GB', '128 GB', '6.7 inch ', '32 MP', '64 MP', '7000 mAh', '-', '-'),
(19, 'Samsung Galaxy Z Fold 2', 'Smartphone', '33000000', 100, 'Published', '2021-04-26 11:07:19', '2021-04-26 11:07:19', 'samsung z fold 2.png', 'Samsung', 'Grey', '5G', 'Android', 'Snapdragon 865', '12 GB', '256 GB', '7.6 inch ', '12 MP', '32 MP', '4500 mAh', '-', '-'),
(20, 'Xiaomi mi note 10', 'Smartphone', '7900000', 100, 'Published', '2021-04-26 11:09:54', '2021-04-26 11:09:54', 'Xiaomi Mi Note 10 green.png', 'Xiaomi', 'Green', '4G', 'Android', 'Qualcomm SDM730 Snapdragon 730G ', '6 GB', '128 GB', '6.4 inch ', '12 MP', '108 MP', '5260 mAh', '-', '-'),
(21, 'Xiaomi redmi note 9', 'Smartphone', '2100000', 100, 'Published', '2021-04-26 11:12:34', '2021-04-26 11:12:34', 'Xiaomi Redmi Note 9 black.jpg', 'Xiaomi', 'Black', '4G', 'Android', 'MediaTek Helio G85 (12nm)', '4 GB', '128 GB', '6.5 inch ', '8 MP', '48 MP', '5020 mAh', '-', '-'),
(22, 'Xiaomi mi 9', 'Smartphone', '6500000', 100, 'Published', '2021-04-26 11:14:19', '2021-04-26 11:14:19', 'xiaomi mi 9 blue.jpg', 'Xiaomi', 'Blue', '4G', 'Android', 'Qualcomm SM8150 Snapdragon 855 (7 nm)', '6 GB', '128 GB', '6.3 inch ', '16 MP', '48 MP', '3300 mAh', '-', '-'),
(23, 'Realme 6', 'Smartphone', '30000000', 100, 'Published', '2021-04-26 11:16:03', '2021-04-26 11:16:03', 'realme 6 comet blue.jpg', 'Realme', 'Comet Blue', '4G', 'Android', 'MediaTek G90T', '8 GB', '128 GB', '6.5 inch ', '12 MP', '64 MP', '4300 mAh', '-', '-'),
(24, 'Realme X50 Pro', 'Smartphone', '10000000', 100, 'Published', '2021-04-26 11:17:40', '2021-04-26 11:17:40', 'realme x50.jpg', 'Realme', 'Rust Red', '5G', 'Android', 'Snapdragon 865', '12 GB', '256 GB', '6.4 inch ', '12 MP', '64 MP', '4200 mAh', '-', '-'),
(25, 'Realme 8 Pro', 'Smartphone', '45000000', 100, 'Published', '2021-04-26 11:19:17', '2021-04-26 11:19:17', 'realme 8 pro.png', 'Realme', 'Infinite Black', '5G', 'Android', 'Snapdragon 720G', '8 GB', '128 GB', '6.4 inch ', '12 MP', '64 MP', '4200mAh', '-', '-');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`ID_Produk`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `ID_Produk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
